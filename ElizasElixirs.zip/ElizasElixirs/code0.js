gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects3= [];
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects4= [];
gdjs.Untitled_32sceneCode.GDRightShelfObjects1= [];
gdjs.Untitled_32sceneCode.GDRightShelfObjects2= [];
gdjs.Untitled_32sceneCode.GDRightShelfObjects3= [];
gdjs.Untitled_32sceneCode.GDRightShelfObjects4= [];
gdjs.Untitled_32sceneCode.GDLeftShelfObjects1= [];
gdjs.Untitled_32sceneCode.GDLeftShelfObjects2= [];
gdjs.Untitled_32sceneCode.GDLeftShelfObjects3= [];
gdjs.Untitled_32sceneCode.GDLeftShelfObjects4= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects4= [];
gdjs.Untitled_32sceneCode.GDghostTearsObjects1= [];
gdjs.Untitled_32sceneCode.GDghostTearsObjects2= [];
gdjs.Untitled_32sceneCode.GDghostTearsObjects3= [];
gdjs.Untitled_32sceneCode.GDghostTearsObjects4= [];
gdjs.Untitled_32sceneCode.GDunicornhairObjects1= [];
gdjs.Untitled_32sceneCode.GDunicornhairObjects2= [];
gdjs.Untitled_32sceneCode.GDunicornhairObjects3= [];
gdjs.Untitled_32sceneCode.GDunicornhairObjects4= [];
gdjs.Untitled_32sceneCode.GDdragonScalesObjects1= [];
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2= [];
gdjs.Untitled_32sceneCode.GDdragonScalesObjects3= [];
gdjs.Untitled_32sceneCode.GDdragonScalesObjects4= [];
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1= [];
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2= [];
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3= [];
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects4= [];
gdjs.Untitled_32sceneCode.GDcustomer1Objects1= [];
gdjs.Untitled_32sceneCode.GDcustomer1Objects2= [];
gdjs.Untitled_32sceneCode.GDcustomer1Objects3= [];
gdjs.Untitled_32sceneCode.GDcustomer1Objects4= [];
gdjs.Untitled_32sceneCode.GDSplashObjects1= [];
gdjs.Untitled_32sceneCode.GDSplashObjects2= [];
gdjs.Untitled_32sceneCode.GDSplashObjects3= [];
gdjs.Untitled_32sceneCode.GDSplashObjects4= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects4= [];
gdjs.Untitled_32sceneCode.GDHoverHereObjects1= [];
gdjs.Untitled_32sceneCode.GDHoverHereObjects2= [];
gdjs.Untitled_32sceneCode.GDHoverHereObjects3= [];
gdjs.Untitled_32sceneCode.GDHoverHereObjects4= [];
gdjs.Untitled_32sceneCode.GDredcaulObjects1= [];
gdjs.Untitled_32sceneCode.GDredcaulObjects2= [];
gdjs.Untitled_32sceneCode.GDredcaulObjects3= [];
gdjs.Untitled_32sceneCode.GDredcaulObjects4= [];
gdjs.Untitled_32sceneCode.GDbluecaulObjects1= [];
gdjs.Untitled_32sceneCode.GDbluecaulObjects2= [];
gdjs.Untitled_32sceneCode.GDbluecaulObjects3= [];
gdjs.Untitled_32sceneCode.GDbluecaulObjects4= [];
gdjs.Untitled_32sceneCode.GDyellowcaulObjects1= [];
gdjs.Untitled_32sceneCode.GDyellowcaulObjects2= [];
gdjs.Untitled_32sceneCode.GDyellowcaulObjects3= [];
gdjs.Untitled_32sceneCode.GDyellowcaulObjects4= [];
gdjs.Untitled_32sceneCode.GDgreencaulObjects1= [];
gdjs.Untitled_32sceneCode.GDgreencaulObjects2= [];
gdjs.Untitled_32sceneCode.GDgreencaulObjects3= [];
gdjs.Untitled_32sceneCode.GDgreencaulObjects4= [];
gdjs.Untitled_32sceneCode.GDpurpcaulObjects1= [];
gdjs.Untitled_32sceneCode.GDpurpcaulObjects2= [];
gdjs.Untitled_32sceneCode.GDpurpcaulObjects3= [];
gdjs.Untitled_32sceneCode.GDpurpcaulObjects4= [];
gdjs.Untitled_32sceneCode.GDemptycaulObjects1= [];
gdjs.Untitled_32sceneCode.GDemptycaulObjects2= [];
gdjs.Untitled_32sceneCode.GDemptycaulObjects3= [];
gdjs.Untitled_32sceneCode.GDemptycaulObjects4= [];
gdjs.Untitled_32sceneCode.GDtestObjects1= [];
gdjs.Untitled_32sceneCode.GDtestObjects2= [];
gdjs.Untitled_32sceneCode.GDtestObjects3= [];
gdjs.Untitled_32sceneCode.GDtestObjects4= [];
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1= [];
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2= [];
gdjs.Untitled_32sceneCode.GDgoodPotionObjects3= [];
gdjs.Untitled_32sceneCode.GDgoodPotionObjects4= [];
gdjs.Untitled_32sceneCode.GDspeechCatObjects1= [];
gdjs.Untitled_32sceneCode.GDspeechCatObjects2= [];
gdjs.Untitled_32sceneCode.GDspeechCatObjects3= [];
gdjs.Untitled_32sceneCode.GDspeechCatObjects4= [];
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1= [];
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2= [];
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects3= [];
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects4= [];
gdjs.Untitled_32sceneCode.GDscoreValObjects1= [];
gdjs.Untitled_32sceneCode.GDscoreValObjects2= [];
gdjs.Untitled_32sceneCode.GDscoreValObjects3= [];
gdjs.Untitled_32sceneCode.GDscoreValObjects4= [];
gdjs.Untitled_32sceneCode.GDcustomer2Objects1= [];
gdjs.Untitled_32sceneCode.GDcustomer2Objects2= [];
gdjs.Untitled_32sceneCode.GDcustomer2Objects3= [];
gdjs.Untitled_32sceneCode.GDcustomer2Objects4= [];
gdjs.Untitled_32sceneCode.GDspeechKnightObjects1= [];
gdjs.Untitled_32sceneCode.GDspeechKnightObjects2= [];
gdjs.Untitled_32sceneCode.GDspeechKnightObjects3= [];
gdjs.Untitled_32sceneCode.GDspeechKnightObjects4= [];
gdjs.Untitled_32sceneCode.GDcustomer3Objects1= [];
gdjs.Untitled_32sceneCode.GDcustomer3Objects2= [];
gdjs.Untitled_32sceneCode.GDcustomer3Objects3= [];
gdjs.Untitled_32sceneCode.GDcustomer3Objects4= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects4= [];
gdjs.Untitled_32sceneCode.GDfinalSplashObjects1= [];
gdjs.Untitled_32sceneCode.GDfinalSplashObjects2= [];
gdjs.Untitled_32sceneCode.GDfinalSplashObjects3= [];
gdjs.Untitled_32sceneCode.GDfinalSplashObjects4= [];
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects1= [];
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2= [];
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects3= [];
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects4= [];
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects1= [];
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2= [];
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects3= [];
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects4= [];
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects1= [];
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2= [];
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects3= [];
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects4= [];
gdjs.Untitled_32sceneCode.GDbatSpeechObjects1= [];
gdjs.Untitled_32sceneCode.GDbatSpeechObjects2= [];
gdjs.Untitled_32sceneCode.GDbatSpeechObjects3= [];
gdjs.Untitled_32sceneCode.GDbatSpeechObjects4= [];

gdjs.Untitled_32sceneCode.conditionTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition3IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition4IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition5IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition6IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.conditionTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition2IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition3IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition4IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition5IsTrue_1 = {val:false};
gdjs.Untitled_32sceneCode.condition6IsTrue_1 = {val:false};


gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDHoverHereObjects1Objects = Hashtable.newFrom({"HoverHere": gdjs.Untitled_32sceneCode.GDHoverHereObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects3);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects3[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDghostTearsObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].setX(2);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].setY(158);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects3);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i].getBehavior("Draggable").isDragged() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects3[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9047140);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}}

}


{


{
}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i].setX(1088);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i].setY(352);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getBehavior("Draggable").isDragged() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9051692);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}}

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects3);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDdragonScalesObjects3 */
gdjs.copyArray(runtimeScene.getObjects("redcaul"), gdjs.Untitled_32sceneCode.GDredcaulObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i].setX(12);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i].setY(376);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "PlasticScales.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects3[i].getVariables().getFromIndex(0), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDredcaulObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDredcaulObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getBehavior("Draggable").isDragged() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9056316);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "PlasticScales.mp3", false, 50, 1);
}}

}


};gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects3);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects3[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDunicornhairObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i].setX(1048);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i].setY(-(9));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-arrow-whoosh-1491.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getBehavior("Draggable").isDragged() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9059956);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-arrow-whoosh-1491.wav", false, 50, 1);
}}

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setX(1111);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setY(195);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].getBehavior("Draggable").isDragged() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9062956);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-glass-hitting-a-metal-2183.wav", false, 50, 1);
}}

}


};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRegenRecipeObjects2Objects = Hashtable.newFrom({"RegenRecipe": gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer1Objects2Objects = Hashtable.newFrom({"customer1": gdjs.Untitled_32sceneCode.GDcustomer1Objects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects = Hashtable.newFrom({"test": gdjs.Untitled_32sceneCode.GDtestObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDmadePotionCompleteObjects1Objects = Hashtable.newFrom({"madePotionComplete": gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1});
gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("customer1"), gdjs.Untitled_32sceneCode.GDcustomer1Objects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDcustomer1Objects2[k] = gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.Untitled_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDtestObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDtestObjects2[0] : null), 300, 0);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("RegenRecipe"), gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RegenRecipe"), gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRegenRecipeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2[i].isVisible() ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2[k] = gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("customer1"), gdjs.Untitled_32sceneCode.GDcustomer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer1Objects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.Untitled_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("speechCat"), gdjs.Untitled_32sceneCode.GDspeechCatObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechCatObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechCatObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].clearForces();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects2[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition1IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9068516);
}
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "wrong-answer-126515.mp3", false, 50, 1);
}{runtimeScene.getScene().getVariables().get("score").sub(5);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects2[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition1IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9070596);
}
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "wrong-answer-126515.mp3", false, 50, 1);
}{runtimeScene.getScene().getVariables().get("score").sub(5);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects2[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9073004);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getBehavior("Draggable").wasJustDropped() ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9074748);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("redcaul"), gdjs.Untitled_32sceneCode.GDredcaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDredcaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDredcaulObjects2[i].hide(false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() >= 140 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getY() < 600 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);
gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);
gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition3IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9078564);
}
}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
}
}
if (gdjs.Untitled_32sceneCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-achievement-bell-600.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() >= 200 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getY() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() <= 500 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("customer1"), gdjs.Untitled_32sceneCode.GDcustomer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);
gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
gdjs.copyArray(runtimeScene.getObjects("madePotionComplete"), gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2);
gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer1Objects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setX(1111);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setY(195);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("madePotionComplete"), gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDmadePotionCompleteObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i].isVisible() ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[k] = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("customer1"), gdjs.Untitled_32sceneCode.GDcustomer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects1);
/* Reuse gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1 */
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("redcaul"), gdjs.Untitled_32sceneCode.GDredcaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects1);
gdjs.copyArray(runtimeScene.getObjects("speechCat"), gdjs.Untitled_32sceneCode.GDspeechCatObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDredcaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDredcaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechCatObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechCatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer2Objects1[i].getVariables().getFromIndex(0), true);
}
}{runtimeScene.getScene().getVariables().get("score").add(30);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer2Objects2Objects = Hashtable.newFrom({"customer2": gdjs.Untitled_32sceneCode.GDcustomer2Objects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects = Hashtable.newFrom({"test": gdjs.Untitled_32sceneCode.GDtestObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDstrengthRecipeObjects2Objects = Hashtable.newFrom({"strengthRecipe": gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDmadePotionCompleteObjects1Objects = Hashtable.newFrom({"madePotionComplete": gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1});
gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDcustomer2Objects2[k] = gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDtestObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDtestObjects2[0] : null), 300, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects2);
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer2Objects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects, false, runtimeScene, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("speechKnight"), gdjs.Untitled_32sceneCode.GDspeechKnightObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechKnightObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechKnightObjects2[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("strengthRecipe"), gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("strengthRecipe"), gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDstrengthRecipeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2[i].isVisible() ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2[k] = gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9091740);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "wrong-answer-126515.mp3", false, 50, 1);
}{runtimeScene.getScene().getVariables().get("score").sub(5);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects2[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9094164);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("greencaul"), gdjs.Untitled_32sceneCode.GDgreencaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgreencaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgreencaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects2[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9095796);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bluecaul"), gdjs.Untitled_32sceneCode.GDbluecaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbluecaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbluecaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition0IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9096836);
}
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects2[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);
gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9099524);
}
}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects2[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = k;}}
}
}
}
if (gdjs.Untitled_32sceneCode.condition4IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() >= 340 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() <= 890 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getY() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition4IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9101284);
}
}}
}
}
}
if (gdjs.Untitled_32sceneCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-achievement-bell-600.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() >= 200 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getY() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() <= 450 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects2);
gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);
gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
gdjs.copyArray(runtimeScene.getObjects("madePotionComplete"), gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2);
gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer2Objects2[i].getVariables().get("ComeUp"), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setX(1111);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setY(195);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("madePotionComplete"), gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDmadePotionCompleteObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i].isVisible() ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[k] = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bluecaul"), gdjs.Untitled_32sceneCode.GDbluecaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("customer3"), gdjs.Untitled_32sceneCode.GDcustomer3Objects1);
gdjs.copyArray(runtimeScene.getObjects("greencaul"), gdjs.Untitled_32sceneCode.GDgreencaulObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1 */
gdjs.copyArray(runtimeScene.getObjects("redcaul"), gdjs.Untitled_32sceneCode.GDredcaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects1);
gdjs.copyArray(runtimeScene.getObjects("speechKnight"), gdjs.Untitled_32sceneCode.GDspeechKnightObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbluecaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbluecaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDredcaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDredcaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgreencaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgreencaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechKnightObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechKnightObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer3Objects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer3Objects1[i].getVariables().get("comeUp"), true);
}
}{runtimeScene.getScene().getVariables().get("score").add(30);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer3Objects2Objects = Hashtable.newFrom({"customer3": gdjs.Untitled_32sceneCode.GDcustomer3Objects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects = Hashtable.newFrom({"test": gdjs.Untitled_32sceneCode.GDtestObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDwizardRecipeObjects2Objects = Hashtable.newFrom({"wizardRecipe": gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2});
gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("customer3"), gdjs.Untitled_32sceneCode.GDcustomer3Objects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].getVariables().get("comeUp"), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDcustomer3Objects2[k] = gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length = k;}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer3Objects2 */
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDtestObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDtestObjects2[0] : null), 300, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("customer3"), gdjs.Untitled_32sceneCode.GDcustomer3Objects2);
gdjs.copyArray(runtimeScene.getObjects("test"), gdjs.Untitled_32sceneCode.GDtestObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDcustomer3Objects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDtestObjects2Objects, false, runtimeScene, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("batSpeech"), gdjs.Untitled_32sceneCode.GDbatSpeechObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDcustomer3Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer3Objects2[i].getVariables().get("comeUp"), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbatSpeechObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbatSpeechObjects2[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wizardRecipe"), gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDwizardRecipeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2[i].isVisible() ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2[k] = gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}}
}
}
if (gdjs.Untitled_32sceneCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("wizardRecipe"), gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2[i].hide(false);
}
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9114388);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9116132);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("greencaul"), gdjs.Untitled_32sceneCode.GDgreencaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgreencaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgreencaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects2[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition2IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9117764);
}
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bluecaul"), gdjs.Untitled_32sceneCode.GDbluecaulObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbluecaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbluecaulObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition0IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9118804);
}
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects2[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-magic-potion-music-and-fx-2831.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects2);
gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects2);
gdjs.copyArray(runtimeScene.getObjects("unicornhair"), gdjs.Untitled_32sceneCode.GDunicornhairObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition5IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[k] = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[k] = gdjs.Untitled_32sceneCode.GDdragonScalesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDghostTearsObjects2[k] = gdjs.Untitled_32sceneCode.GDghostTearsObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDunicornhairObjects2[k] = gdjs.Untitled_32sceneCode.GDunicornhairObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition4IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition5IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9121892);
}
}}
}
}
}
}
if (gdjs.Untitled_32sceneCode.condition5IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects2);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() >= 340 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getX() <= 890 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getY() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition4IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9123452);
}
}}
}
}
}
if (gdjs.Untitled_32sceneCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-achievement-bell-600.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("goodPotion"), gdjs.Untitled_32sceneCode.GDgoodPotionObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].getX() >= 200 ) {
        gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].getY() <= 800 ) {
        gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].getX() <= 450 ) {
        gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[k] = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length = k;}if ( gdjs.Untitled_32sceneCode.condition2IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
}if ( gdjs.Untitled_32sceneCode.condition3IsTrue_0.val ) {
{
{gdjs.Untitled_32sceneCode.conditionTrue_1 = gdjs.Untitled_32sceneCode.condition4IsTrue_0;
gdjs.Untitled_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9125060);
}
}}
}
}
}
if (gdjs.Untitled_32sceneCode.condition4IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("customer2"), gdjs.Untitled_32sceneCode.GDcustomer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("dragonScales"), gdjs.Untitled_32sceneCode.GDdragonScalesObjects1);
gdjs.copyArray(runtimeScene.getObjects("finalSplash"), gdjs.Untitled_32sceneCode.GDfinalSplashObjects1);
gdjs.copyArray(runtimeScene.getObjects("frogsBreath"), gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghostTears"), gdjs.Untitled_32sceneCode.GDghostTearsObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDgoodPotionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer2Objects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer2Objects1[i].getVariables().get("ComeUp"), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdragonScalesObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdragonScalesObjects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDdragonScalesObjects1[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].setX(1111);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgoodPotionObjects1[i].setY(195);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDghostTearsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDghostTearsObjects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDghostTearsObjects1[i].getVariables().getFromIndex(0), false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}{runtimeScene.getScene().getVariables().get("score").add(30);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfinalSplashObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfinalSplashObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setString(" " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setY(425);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setX(750);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setCharacterSize(100);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HoverHere"), gdjs.Untitled_32sceneCode.GDHoverHereObjects1);
gdjs.copyArray(runtimeScene.getObjects("RegenRecipe"), gdjs.Untitled_32sceneCode.GDRegenRecipeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Splash"), gdjs.Untitled_32sceneCode.GDSplashObjects1);
gdjs.copyArray(runtimeScene.getObjects("batSpeech"), gdjs.Untitled_32sceneCode.GDbatSpeechObjects1);
gdjs.copyArray(runtimeScene.getObjects("bluecaul"), gdjs.Untitled_32sceneCode.GDbluecaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("finalSplash"), gdjs.Untitled_32sceneCode.GDfinalSplashObjects1);
gdjs.copyArray(runtimeScene.getObjects("greencaul"), gdjs.Untitled_32sceneCode.GDgreencaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("madePotionComplete"), gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1);
gdjs.copyArray(runtimeScene.getObjects("purpcaul"), gdjs.Untitled_32sceneCode.GDpurpcaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("redcaul"), gdjs.Untitled_32sceneCode.GDredcaulObjects1);
gdjs.copyArray(runtimeScene.getObjects("scoreVal"), gdjs.Untitled_32sceneCode.GDscoreValObjects1);
gdjs.copyArray(runtimeScene.getObjects("speechCat"), gdjs.Untitled_32sceneCode.GDspeechCatObjects1);
gdjs.copyArray(runtimeScene.getObjects("speechKnight"), gdjs.Untitled_32sceneCode.GDspeechKnightObjects1);
gdjs.copyArray(runtimeScene.getObjects("strengthRecipe"), gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects1);
gdjs.copyArray(runtimeScene.getObjects("wizardRecipe"), gdjs.Untitled_32sceneCode.GDwizardRecipeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSplashObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSplashObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Kalimba_-_AkashicRecords.mp3", true, 30, 1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHoverHereObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHoverHereObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechCatObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechCatObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpurpcaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpurpcaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDredcaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDredcaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDspeechKnightObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDspeechKnightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreValObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreValObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("score"))));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgreencaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgreencaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbluecaulObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbluecaulObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfinalSplashObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfinalSplashObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRegenRecipeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRegenRecipeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDwizardRecipeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDwizardRecipeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbatSpeechObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbatSpeechObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HoverHere"), gdjs.Untitled_32sceneCode.GDHoverHereObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDHoverHereObjects1Objects, runtimeScene, true, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Untitled_32sceneCode.GDHoverHereObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Splash"), gdjs.Untitled_32sceneCode.GDSplashObjects1);
gdjs.copyArray(runtimeScene.getObjects("customer1"), gdjs.Untitled_32sceneCode.GDcustomer1Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSplashObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSplashObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHoverHereObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHoverHereObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcustomer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcustomer1Objects1[i].setVariableBoolean(gdjs.Untitled_32sceneCode.GDcustomer1Objects1[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{


gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
}


{



}


{


gdjs.Untitled_32sceneCode.eventsList6(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDForestBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDForestBackgroundObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRightShelfObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRightShelfObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRightShelfObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRightShelfObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDLeftShelfObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLeftShelfObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLeftShelfObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDLeftShelfObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDghostTearsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDghostTearsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDghostTearsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDghostTearsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDunicornhairObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDunicornhairObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDunicornhairObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDunicornhairObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDdragonScalesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdragonScalesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdragonScalesObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdragonScalesObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDfrogsBreathObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer1Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer1Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDSplashObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSplashObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSplashObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDSplashObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDHoverHereObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHoverHereObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHoverHereObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHoverHereObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDredcaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDredcaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDredcaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDredcaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbluecaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbluecaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbluecaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbluecaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDyellowcaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDyellowcaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDyellowcaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDyellowcaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDgreencaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgreencaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgreencaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgreencaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDpurpcaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDpurpcaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDpurpcaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDpurpcaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDemptycaulObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDemptycaulObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDemptycaulObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDemptycaulObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDgoodPotionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgoodPotionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgoodPotionObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgoodPotionObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDspeechCatObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDspeechCatObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDspeechCatObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDspeechCatObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDmadePotionCompleteObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDscoreValObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDscoreValObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDscoreValObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDscoreValObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDspeechKnightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDspeechKnightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDspeechKnightObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDspeechKnightObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDcustomer3Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDfinalSplashObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfinalSplashObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDfinalSplashObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDfinalSplashObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRegenRecipeObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDwizardRecipeObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDstrengthRecipeObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbatSpeechObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbatSpeechObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbatSpeechObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbatSpeechObjects4.length = 0;

gdjs.Untitled_32sceneCode.eventsList9(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
